/*
 * Configure use with systemd and logind for suspend mechanisms
 */

#define SYSTEMD
/* #undef DEBUG */
