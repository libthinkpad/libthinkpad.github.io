#ifndef __HOOK_H__
#define __HOOK_H__

class Hooks {
public:
	void executeUndockHook();
	void executeDockHook();
};

#endif
